
// Toggle del menú móvil accesible
const btn = document.querySelector('.nav-toggle');
const nav = document.getElementById('primary-nav');
if (btn && nav) {
  btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!expanded));
    nav.classList.toggle('open');
  });
}
// Año dinámico en el footer
const y = document.getElementById('year');
if (y) y.textContent = new Date().getFullYear();
// Marcar enlace activo en navegación
const links = document.querySelectorAll('.nav a[href^="#"]');
const onIntersect = (entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.id;
      links.forEach(a => {
        a.removeAttribute('aria-current');
        if (a.getAttribute('href') === '#' + id) a.setAttribute('aria-current', 'page');
      });
    }
  });
};
const observer = new IntersectionObserver(onIntersect, {rootMargin: "-30% 0px -60% 0px", threshold: 0});
document.querySelectorAll('section[id]').forEach(sec => observer.observe(sec));
